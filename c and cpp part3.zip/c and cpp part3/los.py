#python logical operator
#not operator
a=10
b=10
c=20
if(not(a!=b) or not(c==a)):
    print("true")
else:
    print("false")