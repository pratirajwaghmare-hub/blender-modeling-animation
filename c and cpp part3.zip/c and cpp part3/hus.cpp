#include <iostream>
#include <windows.h>
using namespace std;

void drawStarMan(int pos, bool step)
{
    // Head
    for(int i = 0; i < pos; i++) cout << " ";
    cout << "*" << endl;

    // Arms and Body
    for(int i = 0; i < pos; i++) cout << " ";
    cout << "***" << endl;

    // Legs Animation
    for(int i = 0; i < pos; i++) cout << " ";

    if(step)
        cout << "* *" << endl;   // Legs open
    else
        cout << " *" << endl;    // Legs together
}

int main()
{
    int pos = 0;

    while(pos < 70)
    {
        system("cls");

        drawStarMan(pos, pos % 2 == 0);

        cout << "\n";
        cout << "============================================================\n";

        Sleep(120);
        pos++;
    }

    return 0;
}
