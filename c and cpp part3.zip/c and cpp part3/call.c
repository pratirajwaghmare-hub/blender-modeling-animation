#include <stdio.h>
#define var int
var tech(var *a, var *b)
{
    var temp;

    temp = *a;
    *a = *b;
    *b = temp;
}

var main()
{
    var x = 10;
    var y = 20;
    var z = x+y;

    printf("Function call se pehle\n");
    printf("x = %d\n", x);
    printf("y = %d\n\n", y);

    tech(&x, &y);

    printf("Function call ke baad\n");
    printf("x = %d\n", x);
    printf("y = %d\n", y);
    printf("%d",z);

    return 0;
}
