#include <opencv2/opencv.hpp>

using namespace cv;

int main()
{
    VideoCapture camera(0);

    if (!camera.isOpened())
    {
        printf("Camera Open Failed!\n");
        return -1;
    }

    Mat frame;

    printf("Press SPACE to Capture Image\n");
    printf("Press ESC to Exit\n");

    while (1)
    {
        camera >> frame;

        if (frame.empty())
            break;

        imshow("Camera", frame);

        int key = waitKey(30);

        if (key == 32) // SPACE
        {
            imwrite("capture.jpg", frame);
            printf("Image Saved Successfully!\n");
        }

        if (key == 27) // ESC
            break;
    }

    camera.release();
    destroyAllWindows();

    return 0;
}
