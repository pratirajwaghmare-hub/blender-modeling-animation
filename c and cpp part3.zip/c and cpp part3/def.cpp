#include<iostream>
using namespace std;
int tech(){
	int a;
	int *ptr;
	ptr = &a;
	cout<<ptr;
}
int main(){
	tech();
}
