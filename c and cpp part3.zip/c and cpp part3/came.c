#include <opencv2/opencv.hpp>

int main() {
    cv::VideoCapture camera(0);

    if (!camera.isOpened()) {
        printf("Camera open failed!\n");
        return -1;
    }

    cv::Mat frame;

    while (1) {
        camera >> frame;

        if (frame.empty())
            break;

        cv::imshow("Camera", frame);

        if (cv::waitKey(1) == 27) // ESC key
            break;
    }

    camera.release();
    cv::destroyAllWindows();

    return 0;
}
