#include <stdio.h>
int tech(int *ptr, int size){
	int i;
	for(i=0;i<=6;i++){
		printf("%d \n",*(ptr + i));
	}
}
int main(){
	int number[] = {1,2,3,4,5,6};
	tech(number,6);
}
