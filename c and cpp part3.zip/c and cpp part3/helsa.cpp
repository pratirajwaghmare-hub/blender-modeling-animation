#include<iostream>
using namespace std;
int main(){
	int i;
	cin>>i;
	int f;
	for(f=0;f<=10;f++){
		int d = f * i;
		cout<<d<<"\n";
	}
	/*cpp table project tutorial*/
}
