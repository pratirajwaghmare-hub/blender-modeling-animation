#include<stdio.h>
#include<conio.h>
/*arithmatic substraction pointer tutorial*/
/*arithmatic pointer substraction tutorial*/
int main(){
	 int arr[] = {10,20,30,40,50};

    int *p1 = &arr[1];
    int *p2 = &arr[5];

    printf("%ld", p2 - p1);
  return 0;
}


