#include <stdio.h>
int main()
{
char *month[] = {
"jan",
"feb",
"mar",
"april",
"may",
"jun",
"july",
"Aug",
"sep",
"oct",
"nov",
"dec",
};
int x;
for(x=0;x<=12;x++)
puts(month[x]);
return(0);
}

